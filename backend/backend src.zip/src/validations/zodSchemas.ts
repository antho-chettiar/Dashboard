import { z } from 'zod';

// Auth schemas
export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

export const refreshTokenSchema = z.object({
  refreshToken: z.string().min(1, 'Refresh token is required'),
});

// User schemas (admin only)
export const createUserSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  role: z.enum(['ADMIN', 'VIEWER']),
});

export const updateUserSchema = z.object({
  email: z.string().email('Invalid email address').optional(),
  role: z.enum(['ADMIN', 'VIEWER']).optional(),
  active: z.boolean().optional(),
});

// Artist schemas
export const createArtistSchema = z.object({
  name: z.string().min(1, 'Name is required').max(255),
  nationality: z.string().max(100).optional().nullable(),
  bio: z.string().max(2000).optional().nullable(),
  photoUrl: z.string().url().optional().nullable(),
  active: z.boolean().optional(),
  genreIds: z.array(z.string()).optional(),
});

export const updateArtistSchema = z.object({
  name: z.string().min(1, 'Name is required').max(255).optional(),
  nationality: z.string().max(100).optional().nullable(),
  bio: z.string().max(2000).optional().nullable(),
  photoUrl: z.string().url().optional().nullable(),
  active: z.boolean().optional(),
  genreIds: z.array(z.string()).optional(),
});

// Concert schemas
export const createConcertSchema = z.object({
  artistId: z.string().cuid('Invalid artist ID'),
  concertName: z.string().max(255).optional().nullable(),
  concertDate: z.string().refine(
    (date) => !isNaN(Date.parse(date)),
    { message: 'Invalid date format' }
  ),
  city: z.string().min(1, 'City is required').max(100),
  state: z.string().max(100).optional().nullable(),
  country: z.string().min(1, 'Country is required').max(100),
  latitude: z.number().min(-90).max(90).optional().nullable(),
  longitude: z.number().min(-180).max(180).optional().nullable(),
  venueName: z.string().max(255).optional().nullable(),
  capacity: z.number().int().positive().optional().nullable(),
  ticketsSold: z.number().int().nonnegative().optional().nullable(),
  avgTicketPrice: z.number().positive().optional().nullable(),
  totalRevenue: z.number().positive().optional().nullable(),
  currency: z.string().length(3).optional().default('INR'),
  notes: z.string().max(5000).optional().nullable(),
});

export const updateConcertSchema = createConcertSchema.partial();

// Platform metric schemas
export const createPlatformMetricSchema = z.object({
  artistId: z.string().cuid('Invalid artist ID'),
  platform: z.enum(['FACEBOOK', 'INSTAGRAM', 'TWITTER', 'YOUTUBE', 'SPOTIFY', 'APPLE_MUSIC', 'REDDIT', 'QUORA']),
  metricDate: z.string().refine(
    (date) => !isNaN(Date.parse(date)),
    { message: 'Invalid date format' }
  ),
  followers: z.number().int().nonnegative().default(0),
  likes: z.number().int().nonnegative().default(0),
  shares: z.number().int().nonnegative().default(0),
  comments: z.number().int().nonnegative().default(0),
  streams: z.number().int().nonnegative().default(0),
});

// Audience demographic schemas
export const createAudienceDemographicSchema = z.object({
  artistId: z.string().cuid('Invalid artist ID').optional().nullable(),
  concertId: z.string().cuid('Invalid concert ID').optional().nullable(),
  dimension: z.enum(['AGE_GROUP', 'GENDER', 'GEOGRAPHY', 'GENRE']),
  dimensionValue: z.string().max(100),
  percentage: z.number().min(0).max(100).optional().nullable(),
  absoluteCount: z.number().int().nonnegative().optional().nullable(),
  sourcePlatform: z.string().max(100).optional().nullable(),
  metricDate: z.string().refine(
    (date) => !isNaN(Date.parse(date)),
    { message: 'Invalid date format' }
  ),
}).refine(
  (data) => data.artistId !== null || data.concertId !== null,
  {
    message: 'Either artistId or concertId must be provided',
    path: ['artistId'],
  }
);

// Query parameter schemas
export const paginationSchema = z.object({
  page: z.string().default('1').transform(val => parseInt(val)),
  limit: z.string().default('50').transform(val => parseInt(val)).refine(val => val > 0 && val <= 100, {
    message: 'Limit must be between 1 and 100',
  }),
});

export const artistQuerySchema = z.object({
  ...paginationSchema.shape,
  search: z.string().optional(),
  genre: z.string().optional(),
  active: z.string().optional().transform(val => val === 'true'),
});

export const concertQuerySchema = z.object({
  ...paginationSchema.shape,
  artistId: z.string().optional(),
  city: z.string().optional(),
  country: z.string().optional(),
  dateFrom: z.string().date().optional(),
  dateTo: z.string().date().optional(),
});

export const metricsQuerySchema = z.object({
  artistId: z.string().cuid('Invalid artist ID'),
  platform: z.enum(['FACEBOOK', 'INSTAGRAM', 'TWITTER', 'YOUTUBE', 'SPOTIFY', 'APPLE_MUSIC', 'REDDIT', 'QUORA']).optional(),
  dateFrom: z.string().date().optional(),
  dateTo: z.string().date().optional(),
});

export const analyticsQuerySchema = z.object({
  artistId: z.string().cuid('Invalid artist ID').optional(),
  platform: z.enum(['FACEBOOK', 'INSTAGRAM', 'TWITTER', 'YOUTUBE', 'SPOTIFY', 'APPLE_MUSIC', 'REDDIT', 'QUORA']).optional(),
  period: z.enum(['daily', 'weekly', 'monthly']).optional().default('daily'),
  dateFrom: z.string().date().optional(),
  dateTo: z.string().date().optional(),
});

export const demographicsQuerySchema = z.object({
  artistId: z.string().cuid('Invalid artist ID').optional(),
  concertId: z.string().cuid('Invalid concert ID').optional(),
  dimension: z.enum(['AGE_GROUP', 'GENDER', 'GEOGRAPHY', 'GENRE']).optional(),
});

// Types for TypeScript
export type LoginInput = z.infer<typeof loginSchema>;
export type CreateArtistInput = z.infer<typeof createArtistSchema>;
export type UpdateArtistInput = z.infer<typeof updateArtistSchema>;
export type CreateConcertInput = z.infer<typeof createConcertSchema>;
export type UpdateConcertInput = z.infer<typeof updateConcertSchema>;
export type CreatePlatformMetricInput = z.infer<typeof createPlatformMetricSchema>;
export type CreateAudienceDemographicInput = z.infer<typeof createAudienceDemographicSchema>;
